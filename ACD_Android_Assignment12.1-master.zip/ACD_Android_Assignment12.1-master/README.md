# ACD_Android_Assignment12.1
This assignment tested my skills in Android preferences learned in the class.   

Objective : This assignment helped me to master the following concepts -> 
            Preferences
            
Problem Statement : You have to create a page/screen in which user can save his password and other choices/details. 

I have created SharedPreferences wherever required. I have created intents to jump to and fro from MainActivity.
I have attached four screenshots, one is of main UI before, second is of password UI, third is of updateFrequency UI and fourth one is of main UI after.

Project has been linked through git repository AVD emulator configuration Nexus 6 API 24 - Android 7.0 (Naugat). Screenshots of output is attached in repository. Source code of the Android App is uploaded in repository.
